#!/usr/bin/env python3
"""
Text Processor Tool - Example OSI Application with pyproject.toml

A simple text processing tool that demonstrates the new wheel-based
OSI deployment model with standard pyproject.toml configuration.
"""

import sys
from pathlib import Path
from typing import List

try:
    import click
    from colorama import init, Fore, Style
except ImportError as e:
    print(f"Error: Missing required dependency: {e}")
    print("Please ensure all dependencies are installed.")
    sys.exit(1)

# Initialize colorama for cross-platform colored output
init()


@click.group()
@click.version_option(version="1.0.0")
def cli():
    """Text Processor - Process and analyze text files."""
    pass


@cli.command()
@click.argument('input_file', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Path(), help='Output file (optional)')
@click.option('--encoding', default='utf-8', help='File encoding (default: utf-8)')
def count(input_file, output, encoding):
    """Count words, lines, and characters in a text file."""
    try:
        input_path = Path(input_file)
        
        with open(input_path, 'r', encoding=encoding) as f:
            content = f.read()
        
        lines = content.split('\n')
        words = content.split()
        chars = len(content)
        chars_no_spaces = len(content.replace(' ', '').replace('\t', '').replace('\n', ''))
        
        results = {
            'file': str(input_path),
            'lines': len(lines),
            'words': len(words),
            'characters': chars,
            'characters_no_spaces': chars_no_spaces
        }
        
        # Display results
        click.echo(f"{Fore.BLUE}Text Analysis Results{Style.RESET_ALL}")
        click.echo("-" * 30)
        click.echo(f"File: {results['file']}")
        click.echo(f"Lines: {results['lines']:,}")
        click.echo(f"Words: {results['words']:,}")
        click.echo(f"Characters: {results['characters']:,}")
        click.echo(f"Characters (no spaces): {results['characters_no_spaces']:,}")
        
        # Save to output file if specified
        if output:
            output_path = Path(output)
            with open(output_path, 'w', encoding=encoding) as f:
                f.write(f"Text Analysis Results\n")
                f.write(f"====================\n")
                f.write(f"File: {results['file']}\n")
                f.write(f"Lines: {results['lines']:,}\n")
                f.write(f"Words: {results['words']:,}\n")
                f.write(f"Characters: {results['characters']:,}\n")
                f.write(f"Characters (no spaces): {results['characters_no_spaces']:,}\n")
            
            click.echo(f"{Fore.GREEN}Results saved to: {output_path}{Style.RESET_ALL}")
        
    except Exception as e:
        click.echo(f"{Fore.RED}Error: {e}{Style.RESET_ALL}")
        sys.exit(1)


@cli.command()
@click.argument('input_file', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Path(), help='Output file (optional)')
@click.option('--encoding', default='utf-8', help='File encoding (default: utf-8)')
@click.option('--case', type=click.Choice(['upper', 'lower', 'title', 'capitalize']), 
              help='Convert case')
def transform(input_file, output, encoding, case):
    """Transform text in various ways."""
    try:
        input_path = Path(input_file)
        
        with open(input_path, 'r', encoding=encoding) as f:
            content = f.read()
        
        # Apply transformations
        if case == 'upper':
            content = content.upper()
        elif case == 'lower':
            content = content.lower()
        elif case == 'title':
            content = content.title()
        elif case == 'capitalize':
            content = content.capitalize()
        
        # Output results
        if output:
            output_path = Path(output)
            with open(output_path, 'w', encoding=encoding) as f:
                f.write(content)
            click.echo(f"{Fore.GREEN}Transformed text saved to: {output_path}{Style.RESET_ALL}")
        else:
            click.echo(f"{Fore.BLUE}Transformed text:{Style.RESET_ALL}")
            click.echo("-" * 20)
            click.echo(content[:500])  # Show first 500 characters
            if len(content) > 500:
                click.echo("...")
        
    except Exception as e:
        click.echo(f"{Fore.RED}Error: {e}{Style.RESET_ALL}")
        sys.exit(1)


@cli.command()
@click.argument('input_file', type=click.Path(exists=True))
@click.argument('search_term')
@click.option('--case-sensitive', is_flag=True, help='Case-sensitive search')
@click.option('--encoding', default='utf-8', help='File encoding (default: utf-8)')
def search(input_file, search_term, case_sensitive, encoding):
    """Search for text in a file."""
    try:
        input_path = Path(input_file)
        
        with open(input_path, 'r', encoding=encoding) as f:
            lines = f.readlines()
        
        matches = []
        search_text = search_term if case_sensitive else search_term.lower()
        
        for line_num, line in enumerate(lines, 1):
            line_text = line if case_sensitive else line.lower()
            if search_text in line_text:
                matches.append((line_num, line.strip()))
        
        if matches:
            click.echo(f"{Fore.GREEN}Found {len(matches)} matches for '{search_term}':{Style.RESET_ALL}")
            click.echo("-" * 50)
            for line_num, line_content in matches:
                click.echo(f"{Fore.YELLOW}{line_num:4d}:{Style.RESET_ALL} {line_content}")
        else:
            click.echo(f"{Fore.RED}No matches found for '{search_term}'{Style.RESET_ALL}")
        
    except Exception as e:
        click.echo(f"{Fore.RED}Error: {e}{Style.RESET_ALL}")
        sys.exit(1)


@cli.command()
@click.argument('input_files', nargs=-1, required=True, type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Path(), help='Output file (required)')
@click.option('--encoding', default='utf-8', help='File encoding (default: utf-8)')
def merge(input_files, output, encoding):
    """Merge multiple text files into one."""
    try:
        if not output:
            click.echo(f"{Fore.RED}Error: Output file is required for merge operation{Style.RESET_ALL}")
            sys.exit(1)
        
        output_path = Path(output)
        merged_content = []
        
        for input_file in input_files:
            input_path = Path(input_file)
            click.echo(f"Reading: {input_path}")
            
            with open(input_path, 'r', encoding=encoding) as f:
                content = f.read()
                merged_content.append(f"=== {input_path.name} ===\n")
                merged_content.append(content)
                merged_content.append("\n\n")
        
        with open(output_path, 'w', encoding=encoding) as f:
            f.writelines(merged_content)
        
        click.echo(f"{Fore.GREEN}Merged {len(input_files)} files into: {output_path}{Style.RESET_ALL}")
        
    except Exception as e:
        click.echo(f"{Fore.RED}Error: {e}{Style.RESET_ALL}")
        sys.exit(1)


if __name__ == '__main__':
    cli()
